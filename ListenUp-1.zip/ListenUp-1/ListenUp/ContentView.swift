//
//  ContentView.swift
//  ListenUp
//
//  Created by Joe Ganley on 12/1/20.
//

import SwiftUI

struct Capsule1: View {
    
    var name: String = "ariana"
    var image: String = "ariana"
    
    var body: some View {
    
    
        VStack {
            let _ = print("this is good")
            Image("ariana")
                .clipShape(Capsule())
                .foregroundColor(.white)
                .shadow(color: .black, radius: 2)
                .shadow(color: .black, radius: 10)
                
//            name
//               .foregroundColor(.white)
//               .font(.system(size: 17, weight: .bold, design: .default))
         }
    }
     
}

struct Capsule2: View {
    var body: some View {
      //let name = Text("Kim Petras")
        VStack {
            Image("kimberly")
                .clipShape(Capsule())
                .foregroundColor(.white)
                .shadow(color: .black, radius: 2)
                .shadow(color: .black, radius: 10)

//            name
//               .foregroundColor(.white)
//               .font(.system(size: 17, weight: .bold, design: .default))
         }


        }
}
       

struct Capsule3: View {
    let name = Text("Joji")
    
    var body: some View {
        VStack {
            Image("joji")
                .clipShape(Capsule())
                .foregroundColor(.white)
                .shadow(color: .black, radius: 2)
                .shadow(color: .black, radius: 10)

//            name
//               .foregroundColor(.white)
//               .font(.system(size: 17, weight: .bold, design: .default))
         }


        }
}

struct Capsule4: View {
    var body: some View {
      //let name = Text("Daniel Caeser")
        VStack {
            Image("daniel")
                .clipShape(Capsule())
                .foregroundColor(.white)
                .shadow(color: .black, radius: 2)
                .shadow(color: .black, radius: 10)
            
//            name
//               .foregroundColor(.white)
//               .font(.system(size: 17, weight: .bold, design: .default))
        }
    }
}

struct Capsule5: View {
    var body: some View {
        //let name = Text("Dua Lipa")
        VStack {
            Image("dua")
                .clipShape(Capsule())
                .foregroundColor(.white)
                .shadow(color: .black, radius: 2)
                .shadow(color: .black, radius: 10)

//            name
//               .foregroundColor(.white)
//               .font(.system(size: 17, weight: .bold, design: .default))
      }
    }
}

struct Capsule6: View {
    var body: some View {
       // let name = Text("Megan Thee Stallion")
        VStack {
            Image("meg")
                .clipShape(Capsule())
                .foregroundColor(.white)
                .shadow(color: .black, radius: 2)
                .shadow(color: .black, radius: 10)

//            name
//               .foregroundColor(.white)
//               .font(.system(size: 17, weight: .bold, design: .default))
        }
    }
}

struct Capsule7: View {
    var body: some View {
        //let name = Text("Cardi B")
        VStack {
            Image("cardi")
                .clipShape(Capsule())
                .foregroundColor(.white)
                .shadow(color: .black, radius: 2)
                .shadow(color: .black, radius: 10)

//            name
//               .foregroundColor(.white)
//               .font(.system(size: 17, weight: .bold, design: .default))
        }
    }
}

struct Capsule8: View {
    var body: some View {
        //let name = Text("Nicki Minaj")
        VStack {
            Image("nicki")
                .clipShape(Capsule())
                .foregroundColor(.white)
                .shadow(color: .black, radius: 2)
                .shadow(color: .black, radius: 10)

//            name
//               .foregroundColor(.white)
//               .font(.system(size: 17, weight: .bold, design: .default))
        }
    }
}

struct Capsule9: View {
    var body: some View {
        //let name = Text("Billie Eilish")
        VStack {
            Image("billie")
                .clipShape(Capsule())
                .foregroundColor(.white)
                .shadow(color: .black, radius: 2)
                .shadow(color: .black, radius: 10)

//            name
//               .foregroundColor(.white)
//               .font(.system(size: 17, weight: .bold, design: .default))
        }
    }
}


struct InstaCapsule: View {
    var body: some View {
        //let name = Text("Billie Eilish")
        VStack {
            Image("insta")
//                .clipShape(Capsule())
//                .foregroundColor(.white)
//                .shadow(color: .black, radius: 2)
//                .shadow(color: .black, radius: 10)

//            name
//               .foregroundColor(.white)
//               .font(.system(size: 17, weight: .bold, design: .default))
        }
    }
}

struct TwitterCapsule: View {
    var body: some View {
        //let name = Text("Billie Eilish")
        VStack {
            Image("twitter")
             

        }
    }
}

struct YouTubeCapsule: View {
    var body: some View {
        //let name = Text("Billie Eilish")
        VStack {
            Image("youtube")
               
                
        }
    }
}

struct KimPhoto: View {
    var body: some View {
        //let name = Text("Billie Eilish")
        VStack {
            Image("kim_profile")
//                //.resizable()
//                .scaledToFit()
        }
    }
}





struct SecondView: View {
    @Environment(\.presentationMode) var presentationMode
    @State var showDetails = false
    
    var body: some View {
        Button(action: {
            print("b3 tapped")
        }) {KimPhoto()}
        ZStack {
            LinearGradient(gradient: Gradient(colors: [.top, .bottom]), startPoint: .top, endPoint: .bottom)
                .edgesIgnoringSafeArea(.all)
            VStack{
                HStack(spacing: 35) {
                    Button(action: {
                        print("b3 tapped")
                    }) {InstaCapsule()}
                   
                    Button(action: {
                        print("b3 tapped")
                    }) {TwitterCapsule()}
                        
                    Button(action: {
                        print("b3 tapped")
                    }) {YouTubeCapsule()}
                }
                Button("Dismiss") {
                    self.presentationMode.wrappedValue.dismiss()
                }
            
                }
            }
           

    
    }
}
        
    


struct ThirdView: View {
    @Environment(\.presentationMode) var presentationMode
    @State var showDetails = false
    
 
    
    var body: some View {
        
//        List(modelData) { weather in
//              HStack {
//                  // 2.
//                  Image(systemName: weather.image)
//                      .frame(width: 50, height: 10, alignment: .leading)
//                  Text("\(weather.temp)º")
//                      .frame(width: 50, height: 10, alignment: .leading)
//                  VStack {
//                      Text(weather.city)
//                  }
//              }.font(.title)
//          }
       
        
           
//            VStack {
//                //background(Color.blue)
//                Image("kim_profile")
//                    //.clipShape(Circle())
//                    .resizable()
//                    .scaledToFit()
//                    .foregroundColor(.black)
//    //            Button(action: {
//    //                print("b3 tapped")
//    //        }) {KimPhoto()}
//    //            .clipShape(Rectangle())
//    //            .foregroundColor(.purple)
//    //            .shadow(color: .black, radius: 2)
//    //            .shadow(color: .black, radius: 10)
//            }

        ZStack {
            LinearGradient(gradient: Gradient(colors: [.top, .bottom]), startPoint: .top, endPoint: .bottom)
                .edgesIgnoringSafeArea(.all)
           
            //Spacer()
            VStack{
              
                HStack(spacing: 35) {
                    Button(action: {
                        print("b3 tapped")
                    }) {InstaCapsule()}
                   
                    Button(action: {
                        print("b3 tapped")
                    }) {TwitterCapsule()}
                        
                    Button(action: {
                        print("b3 tapped")
                    }) {YouTubeCapsule()}
                }
                Button("Dismiss") {
                    self.presentationMode.wrappedValue.dismiss()
                }
            
                }
            }
           

    
    }
}

struct FourthView: View {
    @Environment(\.presentationMode) var presentationMode
    @State var showDetails = false
    var body: some View {
    ZStack {
        LinearGradient(gradient: Gradient(colors: [.top, .bottom]), startPoint: .top, endPoint: .bottom)
            .edgesIgnoringSafeArea(.all)
        VStack{
                
            //Use Form?
            //temp
            Button("Dismiss") {
                self.presentationMode.wrappedValue.dismiss()
                }
            .accentColor(.white)
            }
        }
    
//        Button("Dismiss") {
//            self.presentationMode.wrappedValue.dismiss()
//        }
    }
}



let storedUsername = "JV"
let storedPassword = "JV"


struct ContentView: View {
    //@State private var showingSheet = false
    @State var username: String = ""
    @State var password: String = ""
    
    @State var authenticationDidFail: Bool = false
    @State var authenticationDidSucceed: Bool = false
    
    let name2 = Text("Kim Petras")
    let name3 = Text("Joji")
    
    
    
    var body: some View {
        ZStack{
            LinearGradient(gradient: Gradient(colors: [.top, .bottom]), startPoint: .top, endPoint: .bottom)
                .edgesIgnoringSafeArea(.all)
            
        
        VStack{
            
            WelcomeText()
            WelcomeImage()
            UsernameTextField(username: $username)
            PasswordSecureField(password: $password)
            if authenticationDidFail {
                            Text("Information not correct. Try again.")
                                .offset(y: -10)
                                .foregroundColor(.white)
                        }
          
            Button(action: {
                    if self.username == storedUsername && self.password == storedPassword
                    {
                        self.authenticationDidSucceed = true
                        self.authenticationDidFail = false
                    }else {
                        self.authenticationDidFail = true
                    }
            })
            {
                LoginButtonContent()
            }
        }
        .padding()
        //end of vstack
            
            if authenticationDidSucceed {

               HostingTabBar()
                //OneView()
                        }
        
        }//end of zstack so end of login
        
        } //end of body
    
    
    
    
}//end of content view

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct WelcomeText: View {
    var body: some View {
        Text("Welcome!")
            .font(.largeTitle)
            .fontWeight(.semibold) 
            .padding(.bottom,20)
            .foregroundColor(.white)
    }
}

struct WelcomeImage: View {
    var body: some View {
        Image("billie")
            .resizable()
            .aspectRatio(contentMode: .fill)
            .frame(width: 150, height: 150)
            .clipped()
            .cornerRadius(150)
            .padding(.bottom, 75)
    }
}

struct LoginButtonContent: View {
    var body: some View {
        Text("LOGIN")
            .font(.headline)
            .fontWeight(.semibold)
            .foregroundColor(.white)
            .padding()
            .frame(width: 220, height: 60)
            .background(Color.login)
            .cornerRadius(15.0)
    }
}

struct UsernameTextField: View {
    @Binding var username: String
    var body: some View {
        return TextField("Username", text: $username)
            .padding()
            .background(Color.white)
            .cornerRadius(5.0)
            .padding(.bottom, 20)
    }
}

struct PasswordSecureField: View {
    @Binding var password: String
    var body: some View {
        return SecureField("Password", text: $password)
            .padding()
            .background(Color.white)
            .cornerRadius(5.0)
            .padding(.bottom, 20)
    }
}
