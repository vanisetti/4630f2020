//
//  HomeScreenButtons.swift
//  ListenUp
//
//  Created by vijjuajay on 12/8/20.
//

import SwiftUI

struct Capsule1H: View {
    
    var name: String = "ariana"
    var image: String = "ariana"
    
    var body: some View {
    
    
        VStack {
            let _ = print("this is good")
            Image("ariana")
                .frame(width: 70, height: 70)
                .clipShape(Capsule())
                .foregroundColor(.white)
                .shadow(color: .black, radius: 2)
                .shadow(color: .black, radius: 10)
                //.frame(width: 70, height: 70)
                
//            name
//               .foregroundColor(.white)
//               .font(.system(size: 17, weight: .bold, design: .default))
         }
    }
     
}

struct Capsule2H: View {
    var body: some View {
      //let name = Text("Kim Petras")
        VStack {
            Image("kimberly")
                .frame(width: 70, height: 70)
                .clipShape(Capsule())
                .foregroundColor(.white)
                .shadow(color: .black, radius: 2)
                .shadow(color: .black, radius: 10)

//            name
//               .foregroundColor(.white)
//               .font(.system(size: 17, weight: .bold, design: .default))
         }


        }
}
       

struct Capsule3H: View {
    let name = Text("Joji")
    
    var body: some View {
        VStack {
            Image("joji")
                .frame(width: 70, height: 70)
                .clipShape(Capsule())
                .foregroundColor(.white)
                .shadow(color: .black, radius: 2)
                .shadow(color: .black, radius: 10)

//            name
//               .foregroundColor(.white)
//               .font(.system(size: 17, weight: .bold, design: .default))
         }


        }
}

struct Capsule4H: View {
    var body: some View {
      //let name = Text("Daniel Caeser")
        VStack {
            Image("daniel")
                .frame(width: 70, height: 70)
                .clipShape(Capsule())
                .foregroundColor(.white)
                .shadow(color: .black, radius: 2)
                .shadow(color: .black, radius: 10)
            
//            name
//               .foregroundColor(.white)
//               .font(.system(size: 17, weight: .bold, design: .default))
        }
    }
}

struct Capsule5H: View {
    var body: some View {
        //let name = Text("Dua Lipa")
        VStack {
            Image("dua")
                .frame(width: 70, height: 70)
                .clipShape(Capsule())
                .foregroundColor(.white)
                .shadow(color: .black, radius: 2)
                .shadow(color: .black, radius: 10)

//            name
//               .foregroundColor(.white)
//               .font(.system(size: 17, weight: .bold, design: .default))
      }
    }
}

struct Capsule6H: View {
    var body: some View {
       // let name = Text("Megan Thee Stallion")
        VStack {
            Image("meg")
                .frame(width: 70, height: 70)
                .clipShape(Capsule())
                .foregroundColor(.white)
                .shadow(color: .black, radius: 2)
                .shadow(color: .black, radius: 10)

//            name
//               .foregroundColor(.white)
//               .font(.system(size: 17, weight: .bold, design: .default))
        }
    }
}

struct Capsule7H: View {
    var body: some View {
        //let name = Text("Cardi B")
        VStack {
            Image("cardi")
                .frame(width: 70, height: 70)
                .clipShape(Capsule())
                .foregroundColor(.white)
                .shadow(color: .black, radius: 2)
                .shadow(color: .black, radius: 10)

//            name
//               .foregroundColor(.white)
//               .font(.system(size: 17, weight: .bold, design: .default))
        }
    }
}

struct Capsule8H: View {
    var body: some View {
        //let name = Text("Nicki Minaj")
        VStack {
            Image("nicki")
                .frame(width: 70, height: 70)
                .clipShape(Capsule())
                .foregroundColor(.white)
                .shadow(color: .black, radius: 2)
                .shadow(color: .black, radius: 10)

//            name
//               .foregroundColor(.white)
//               .font(.system(size: 17, weight: .bold, design: .default))
        }
    }
}

struct Capsule9H: View {
    var body: some View {
        //let name = Text("Billie Eilish")
        VStack {
            Image("billie")
                .frame(width: 70, height: 70)
                .clipShape(Capsule())
                .foregroundColor(.white)
                .shadow(color: .black, radius: 2)
                .shadow(color: .black, radius: 10)

//            name
//               .foregroundColor(.white)
//               .font(.system(size: 17, weight: .bold, design: .default))
        }
    }
}



