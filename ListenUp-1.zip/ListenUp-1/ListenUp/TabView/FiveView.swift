//
//  FiveView.swift
//  ListenUp
//
//  Created by vijjuajay on 12/8/20.
//

import SwiftUI

struct FiveView: View {
    var body: some View {
        ZStack{
            LinearGradient(gradient: Gradient(colors: [.top, .bottom]), startPoint: .top, endPoint: .bottom)
                .edgesIgnoringSafeArea(.all)
    }
    }
}

struct FiveView_Previews: PreviewProvider {
    static var previews: some View {
        FiveView()
    }
}
