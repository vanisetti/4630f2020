//
//  fourview.swift
//  ListenUp
//
//  Created by vijjuajay on 12/6/20.
//

import SwiftUI

struct FourView: View {
    init() {
        UITabBar.appearance().backgroundColor = UIColor.secondarySystemBackground
      }
    var body: some View {
        ZStack{
            LinearGradient(gradient: Gradient(colors: [.top, .bottom]), startPoint: .top, endPoint: .bottom)
                .edgesIgnoringSafeArea(.all)
    }
}
}

struct FourView_Previews: PreviewProvider {
    static var previews: some View {
        FourView()
    }
}
