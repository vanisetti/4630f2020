//
//  FiveView.swift
//  ListenUp
//
//  Created by vijjuajay on 12/8/20.
//

import SwiftUI

struct FiveView: View {
    @State private var showingSheet = false
    var body: some View {
        ZStack{
            LinearGradient(gradient: Gradient(colors: [.top, .bottom]), startPoint: .top, endPoint: .bottom)
                .edgesIgnoringSafeArea(.all)
            

           // .edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
            ScrollView{
           
                VStack{
                    HStack{
                        Spacer()
                        
                        VStack{
                            Image("billie")
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .frame(width:150,height:150)
                                .clipShape(Circle())
                                .clipped()
                                .padding(.top,30)
                            Text("Joe & Vijaya")
                                .foregroundColor(.white).bold()
                                .padding(.top,12)
                                .font(.title2)
                            Text("@joevijaya")
                                .foregroundColor(.white)
                                .padding(.top,1)
                            NavigationLink(destination: FiveView()) {
                               EditButtonContent()
                            }.buttonStyle(PlainButtonStyle())
                            .padding(.top,10)
                        }
                        Spacer()
                    }
                    Spacer()
                }
                VStack(spacing:15) {
                    Divider()
                    Text("Followers")
                        .foregroundColor(.white).bold()//.multilineTextAlignment(.leading)
                        .font(.title2)
                        .frame(width: 360, height: 20, alignment:.topLeading)
                        
                    
                    ScrollView(.horizontal) {
                        
                        HStack(spacing: 10) {
                            
                            VStack {
                                NavigationLink(destination: AriView()) {
                                   Capsule1H()
                                }.buttonStyle(PlainButtonStyle())
                            }
                            
                            VStack {
                                NavigationLink(destination: KimView()) {
                                   Capsule2H()
                                }.buttonStyle(PlainButtonStyle())
                            }
                            
                            VStack {
                                VStack {
                                    NavigationLink(destination: JojiView()) {
                                       Capsule3H()
                                    }.buttonStyle(PlainButtonStyle())
                                }
                        }
                            VStack {
                                Button(action: {
                                        self.showingSheet.toggle()
                                }) {Capsule4H()}
                                .sheet(isPresented: $showingSheet) {
                                        ThirdView()
                                }
                            }
                            
                            VStack {
                                Button(action:  {
                                    print("b2 tapped")
                                }) {
                                    Capsule5H()
                                    }
                                }
                            
                            VStack {
                                
                                Button(action:  {
                                    print("b3 tapped")
                                }) {
                                    Capsule6H()
                                    }
                                }
                            VStack {
                                Button(action:  {
                                    print("Ariana Grande")
                                }) {
                                    Capsule7H()
                                }
                                }
                            VStack {
                                Button(action:  {
                                    print("b2 tapped")
                                }) {
                                    Capsule8H()
                                    }
                                }
                            VStack {
                                
                                Button(action:  {
                                    print("b3 tapped")
                                }) {
                                    Capsule9H()
                                    }
                                }
                        }.padding()//end of hstack
                        
                    }
                }//extra
            }//extra
    }
    }
}

struct FiveView_Previews: PreviewProvider {
    static var previews: some View {
        FiveView()
    }
}

struct EditButtonContent: View {
    var body: some View {
        Text("EDIT")
            .font(.headline)
            .fontWeight(.semibold)
            .foregroundColor(.white)
            .padding()
            .frame(width: 70, height: 30)
            .background(Color.categories)
            .cornerRadius(15.0)
    }
}
