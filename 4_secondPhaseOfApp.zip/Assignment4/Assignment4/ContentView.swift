//
//  ContentView.swift
//  how
//
//  Created by vijjuajay on 12/7/20.
//

import SwiftUI

struct ContentView: View {
    @State private var selection = 0
    var body: some View {
        TabView(selection: $selection) {
           OneView()
            .tag(0)
            .tabItem {
               Image(systemName: "person.crop.circle.fill").font(.title)

          }
          TwoView()
            .tag(1)
            .tabItem {
               Image(systemName: "cloud.fill").font(.title)
          }
          ThreeView()
            .tag(2)
            .tabItem {
               Image(systemName: "house.fill").font(.title)
          }
          FourView()
            .tag(3)
            .tabItem {
               Image(systemName: "doc.fill").font(.title)
          }
          FiveView()
              .tag(3)
              .tabItem {
                 Image(systemName: "doc.plaintext.fill").font(.title)
            }

        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct OneView: View {
    var body: some View {
        NavigationView{
        ZStack{
            Image("me")
            .resizable()
            .scaledToFill()
            .edgesIgnoringSafeArea(.all)
            
            Text("Vijaya Anisetti")
                .font(.largeTitle)
                .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                .foregroundColor(/*@START_MENU_TOKEN@*/.black/*@END_MENU_TOKEN@*/)
                .frame(width: 300, height: 400, alignment:.top)
            NavigationLink(destination: ThreeView()) {
               Text("Click for more facts")
                .foregroundColor(.white)
                .font(.title2)
                .frame(width: 300, height: 400, alignment:.bottom)
            }.buttonStyle(PlainButtonStyle())
   
    }.navigationBarHidden(true)
}
    }
}


struct TwoView: View {
    var body: some View {
        NavigationView{
        ZStack{
            Image("weather")
            .resizable()
            .scaledToFill()
            .edgesIgnoringSafeArea(.all)
            
            VStack(alignment: .leading){
            Text("Weather")
                .font(.largeTitle)
                .foregroundColor(.white)
                .frame(width: 200, height: 200)
                .multilineTextAlignment(.leading)
                .alignmentGuide(.leading) { d in d[.leading] }
            Text("I am now : 28 degrees and chilly MT")
                .foregroundColor(.white)
            Text("I am from : 63 degrees and sunny NJ")
                .foregroundColor(.white)
            Text("I'd like to be : 59 and cloudy MA")
                .foregroundColor(.white)
            Text("My family is from : 70 and clear IND ")
                .foregroundColor(.white)
                NavigationLink(destination: ThreeView()) {
                   Text("Click for more facts")
                    .foregroundColor(.white)
                    .font(.title2)
                    .frame(width: 200, height: 50, alignment:.bottom)
                }.buttonStyle(PlainButtonStyle())
            }
    }
        .navigationBarHidden(true)
        }
}
}


struct ThreeView: View {
   
    var body: some View {
        NavigationView{
        ZStack{
            Image("facts")
            .resizable()
            .scaledToFill()
            .edgesIgnoringSafeArea(.all)
            
            VStack(alignment: .leading){
                Text("Facts")
                    .font(.largeTitle)
                    .foregroundColor(.white)
                    .frame(width: 200, height: 200)
                    .multilineTextAlignment(.leading)
                    .alignmentGuide(.leading) { d in d[.leading] }
            Text(" Place of birth : New Jersey")
                .foregroundColor(.white)
            Text(" Where I live now : New Jersey")
                .foregroundColor(.white)
            Text(" Where I’d like to live : Massachusetts")
                .foregroundColor(.white)
            Text(" I have no significant other")
                .foregroundColor(.white)
            Text(" I've lived in India for 9 years")
                .foregroundColor(.white)
            Text(" I've been on the worlds tallest rollercoaster")
                .foregroundColor(.white)
            Text(" My favorite color is ocean blue")
                .foregroundColor(.white)
            Text(" I went to a boarding school")
                    .foregroundColor(.white)
            }

        }.navigationBarHidden(true)
        }
}
}


struct FourView: View {
    var body: some View {
        ZStack{
            Image("resume")
            .resizable()
            .scaledToFill()
            .edgesIgnoringSafeArea(.all)

    }
}
}


struct FiveView: View {
    init() {
        UITabBar.appearance().backgroundColor = UIColor.secondarySystemBackground
      }
    var body: some View {
        ZStack{
            Image("investment")
            .resizable()
                .frame(width: 350, height: 350, alignment: .top)
            //.scaledToFill()
            //.edgesIgnoringSafeArea(.all)
            Text("Unfortunately neither me nor my family has any investments but here's an example pie chart of what my investments could've been otherwise")
                .foregroundColor(.black)
                .frame(width: 300, height: 480, alignment: .bottom)
    }
}
}


