//
//  Assignment4App.swift
//  Assignment4
//
//  Created by vijjuajay on 12/13/20.
//

import SwiftUI

@main
struct Assignment4App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
